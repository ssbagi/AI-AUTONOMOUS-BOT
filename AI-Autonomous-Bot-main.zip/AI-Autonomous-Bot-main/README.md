# AI-Autonomous-Bot

Can AI be made Self-Consciousness to work in autonomous mode ? Just had an idea sharing.  

Just had a thought prompted using Copilot. Just to see if this Scenario is possible. 

![image0](https://github.com/user-attachments/assets/c5a8c717-59ea-4c3c-8c3f-192ef7d8d6a3)

![image4](https://github.com/user-attachments/assets/5a5dac4b-01e7-4c37-9347-474e9f8f5e3d)







